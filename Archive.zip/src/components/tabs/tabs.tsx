import { NavLink, Outlet } from "react-router-dom";
import classes from "./tabs.module.scss";

export const Tabs = () => (
  <>
   
    <Outlet />
  </>
);
